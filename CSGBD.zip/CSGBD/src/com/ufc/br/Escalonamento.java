package com.ufc.br;
import java.util.List;


public class Escalonamento {

	public boolean[] starter(int j) {
		boolean[] v = new boolean[j];
		
		for(int i=0; i<j; i++) {
			v[i] = false;
		}
		
		return v;
		
	}
	
	public boolean detector(List<Transacao>transacoes) {
		
		boolean[] resultado = starter(transacoes.size());
		int ind = 0;
		int cont = 0;
		
		for (Transacao t : transacoes) {
			ind++;
			if(t.getOp().getREADLOCK().equals("ReadLock")) {
				if(t.getTIMESTAMP()<t.getD().getRTS()) {
					//t.getOp().isUnlock(); // t cancelada
					t.setTIMESTAMP(t.getTIMESTAMP());
				}else {
					t.getD().setRTS(t.getTIMESTAMP());
					resultado[ind-1] = true;
				}
			}
			
			else{
				if(t.getTIMESTAMP() < t.getD().getWTS()) {
					//t.getOp().isUnlock(); // t cancelada
					t.setTIMESTAMP(t.getTIMESTAMP());
				}else {
					t.getD().setWTS(t.getTIMESTAMP());
					resultado[ind-1] = true;
				}
			}
		}
		
		for (boolean r : resultado) {
			if(r==true) {
				cont++;
			}
		}
		if(cont==transacoes.size()) {
			return true;
		}
		return false;
		
	}
	
}
