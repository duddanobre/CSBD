package com.ufc.br;

import java.util.ArrayList;
import java.util.List;

public class Principal {
	public static void main(String[] args) {
		Escalonamento esc = new Escalonamento();
		Operacao r = new Operacao("ReadLock", "WriteLock", false);
		Operacao w = new Operacao("ReadLock", "WriteLock", false);
		Dado d1 = new Dado("(X)",0 , 0);
		Dado d2 = new Dado("(Y)",0 , 0);
		Dado d3 = new Dado("(Z)",0 , 0);
		
		List<Transacao> transacoes = new ArrayList<>();
	/*	transacoes.add(new Transacao("T2",1, r, d1));
		transacoes.add(new Transacao("T1",1, w, d1));
		transacoes.add(new Transacao("T1",2, r, d2));
		transacoes.add(new Transacao("T2",1, w, d1));
		transacoes.add(new Transacao("T1",2, w, d2));*/
		
		transacoes.add(new Transacao("T1", 2, r, d1));
		transacoes.add(new Transacao("T2", 1, r, d2));
		transacoes.add(new Transacao("T3", 1, w, d2));
		transacoes.add(new Transacao("T4", 2, r, d2));
		transacoes.add(new Transacao("T2", 1, w, d3));
		transacoes.add(new Transacao("T5", 2, w, d2));
		
		for (Transacao transação : transacoes) {
			System.out.println(transação.getOp().getId() + ", Timestamp " + transação.getTIMESTAMP() +transação.getD().getNome());
			
			
		}
		if(esc.detector(transacoes)) {
			System.out.println("É serializavel :)");
		}else {
			System.out.println("Não é serializavel :(");
}
	}
}
