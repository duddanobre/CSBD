package com.ufc.br;


public class Transacao {
	
	private String nomet;
	private int TIMESTAMP;
	private Operacao op;
	private Dado d;
	
	public int getTIMESTAMP() {
		return TIMESTAMP;
	}
	public void setTIMESTAMP(int tIMESTAMP) {
		TIMESTAMP = tIMESTAMP;
	}
	public Operacao getOp() {
		return op;
	}
	public void setOp(Operacao op) {
		this.op = op;
	}
	public String getNomet() {
		return nomet;
	}
	public void setNomet(String nomet) {
		this.nomet = nomet;
	}
	public Dado getD() {
		return d;
	}
	public void setD(Dado d) {
		this.d = d;
	}
	public Transacao(String nomet, int tIMESTAMP,Operacao op, Dado d) {
		TIMESTAMP = tIMESTAMP;
		this.op = op;
		this.d = d;
		this.nomet = nomet;
	}
	
	
		
	
}

	