package com.ufc.br;


public class Operacao {
	
	String id = "Operação";
	String READLOCK;
	String WRITELOCK;
	
	boolean unlock;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getREADLOCK() {
		return READLOCK;
	}
	public void setREADLOCK(String rEADLOCK) {
		READLOCK = rEADLOCK;
	}
	public String getWRITELOCK() {
		return WRITELOCK;
	}
	public void setWRITELOCK(String wRITELOCK) {
		WRITELOCK = wRITELOCK;
	}
	public boolean isUnlock() {
		return unlock;
	}
	public void setUnlock(boolean unlock) {
		this.unlock = unlock;
	}
	
	public Operacao(String rEADLOCK, String wRITELOCK, boolean unlock) {
		READLOCK = rEADLOCK;
		WRITELOCK = wRITELOCK;
		this.unlock = unlock;
	}
	
	
	
	
}
