package com.ufc.br;

public class Dado {
	// RTS e WTS são as operações e seu TS 
	private String nome;
	private int RTS;
	private int WTS;
	
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getRTS() {
		return RTS;
	}
	public void setRTS(int rTS) {
		RTS = rTS;
	}
	public int getWTS() {
		return WTS;
	}
	public void setWTS(int wTS) {
		WTS = wTS;
	}
	public Dado(String nome, int rTS, int wTS) {
		this.nome = nome;
		RTS = rTS;
		WTS = wTS;
	}
	
	
}
